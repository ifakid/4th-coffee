/*
Nama: Andjani Kiranadewi
NIM: 13518109
File: Expression.java
*/

interface Expression {
	public int solve();
}